import React, { useState, useEffect } from 'react';
import Expenses from './components/Expenses/Expenses';
import NewExpense from './components/NewExpense/NewExpense';
import userEvent from '@testing-library/user-event';
import { type } from '@testing-library/user-event/dist/type';

const App = () => {
  let DUMMY_EXPENSE = [
    {
      id: 'e1',
      title: 'School Fees',
      amount: 250,
      date: new Date(2024, 7, 21)
    },
    {
      id: 'e2',
      title: 'Books',
      amount: 230,
      date: new Date(2024, 2, 20)
    },
    {
      id: 'e3',
      title: 'House Rent',
      amount: 700,
      date: new Date(2024, 4, 2)
    },
    {
      id: 'e4',
      title: 'Foods',
      amount: 550,
      date: new Date(2024, 2, 5)
    }
  ]


  const [expenses, setExpenses] = useState(DUMMY_EXPENSE);


  function fetchData() {
    fetch('http://localhost:3000/expenses')
      .then(response => response.json())
      .then(data => { console.log(data); setExpenses(data) })
      .catch(err => console.error(err));
  }



  useEffect(() => {
    fetchData();
  }, [])

  const addExpenseDataHandler = (expense) => {

    fetch('http://localhost:3000/expenses', {
      method: 'POST',
      body: JSON.stringify(expense),
      headers: { 'content-Type': 'application/json' }
    }).then(response => fetchData());

    // const updatedExpense = [expense, ...expenses]
    // setExpenses(updatedExpense)

  }



  return (
    < div >
      <NewExpense onAddExpense={addExpenseDataHandler} />
      <Expenses expenses={expenses}></Expenses>
    </div >
  )

}


export default App;